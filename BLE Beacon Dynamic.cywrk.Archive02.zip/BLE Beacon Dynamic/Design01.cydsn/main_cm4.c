/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "stdio.h"

/* For GCC compiler revise _write() function for printf functionality */
int _write(int file, char *ptr, int len)
{
    int i;
    file = file;
    for (i = 0; i < len; i++)
    {
        UART_DEB_Put(*ptr);
        ++ptr;
    }
    return len;
}


#define DBG_PRINTF(...)                 (printf(__VA_ARGS__))
#define DBG_PRINTF(...)                 (printf(__VA_ARGS__))
#define UART_DEB_PUT_CHAR(...)           while(1UL != UART_DEB_Put(__VA_ARGS__))
#define UART_DEB_GET_CHAR(...)          (UART_DEB_Get())
#define UART_DEB_IS_TX_COMPLETE(...)    (UART_DEB_IsTxComplete())
#define UART_DEB_WAIT_TX_COMPLETE(...)   while(UART_DEB_IS_TX_COMPLETE() == 0) ;    
#define UART_DEB_SCB_CLEAR_RX_FIFO(...) (Cy_SCB_ClearRxFifo(UART_DEB_SCB__HW))
#define UART_START(...)                 (UART_DEB_Start(__VA_ARGS__))
#define UART_DEB_NO_DATA                (char8) CY_SCB_UART_RX_NO_DATA

#define advPayload                                  (cy_ble_discoveryModeInfo[0].advData[0].advData)

void ProcessUartCommands(char8 command);
void PrintMenu(void);
void AppCallBack(uint32_t event, void* eventParam);
void UpdateADVData(void);
void StartBroadcast(void);
void StopBroadcast(void);

int main(void)
{
    char8 command;
    cy_en_ble_api_result_t apiResult;
    
    UART_DEB_Start();
    
    __enable_irq(); /* Enable global interrupts. */
    
    
    apiResult = Cy_BLE_Start(AppCallBack);
    if(apiResult != CY_BLE_SUCCESS)
    {
        DBG_PRINTF("Cy_BLE_Start API Error: 0x%x", apiResult);
    }

    for(;;)
    {
        
        /* Cy_BLE_ProcessEvents() allows BLE stack to process pending events */
        Cy_BLE_ProcessEvents();
        /* Process command from debug terminal */
        if((command = UART_DEB_GET_CHAR()) != UART_DEB_NO_DATA) 
        {
            ProcessUartCommands(command); 
        }
        
    }
}



/*******************************************************************************
* Function Name: PrintMenu
********************************************************************************
*
* Summary:
*   Print Menu
*
*******************************************************************************/
void PrintMenu(void)
{
    DBG_PRINTF("\r\nSelect operation:\r\n"); 
    DBG_PRINTF("'1' -- start broadcasting \r\n"); 
    DBG_PRINTF("'2' -- stop advertising \r\n\r\n");  
    DBG_PRINTF("'3' -- increment advertising data \r\n\r\n");  
}

/*******************************************************************************
* Function Name: ProcessUartCommands
********************************************************************************
*
* Summary:
*   Process UART user commands
*
*******************************************************************************/
void ProcessUartCommands(char8 command)
{
   switch(command)
    {     
        case '1':  /* Start broadcasting as Eddystone-URL Beacon */  
        {  
            DBG_PRINTF("\r\nStart broadcasting \r\n");
            StartBroadcast();    
            break;   
        }   
       
        case '2': /* Stop advertising */
        {
            DBG_PRINTF("\r\nStop broadcasting \r\n");
            StopBroadcast();        
            break;
        }
        
        case '3': /* increment advertising data*/
        {  
            UpdateADVData();
            Cy_SysLib_Delay(50);
            break;
        }
        
        case 'h':
            PrintMenu();
            break;
            
        default:
            DBG_PRINTF("Unsupported command\r\n");
            break;
    }
}


/*******************************************************************************
* Function Name: AppCallBack
********************************************************************************
*
* Summary:
*   This is an event callback function to receive events from the BLE Component.
*
* Parameters:
*  event      - the event code
*  eventParam - the event parameters
*
*******************************************************************************/
void AppCallBack(uint32_t event, void* eventParam)
{
      
    switch(event)
    {
        case CY_BLE_EVT_STACK_ON:
            DBG_PRINTF("CY_BLE_EVT_STACK_ON, StartAdvertisement \r\n");
            
            /* Enter into broadcast mode with default values. */
           StartBroadcast();                
          
            /* Print the operation menu */
            PrintMenu();
            break;

        case CY_BLE_EVT_TIMEOUT:
            DBG_PRINTF("CY_BLE_EVT_TIMEOUT \r\n");
            break;
            
        case CY_BLE_EVT_HARDWARE_ERROR:    /* This event indicates that some internal HW error has occurred. */
            DBG_PRINTF("CY_BLE_EVT_HARDWARE_ERROR \r\n");
            break;
            
        case CY_BLE_EVT_STACK_BUSY_STATUS:
            DBG_PRINTF("CY_BLE_EVT_STACK_BUSY_STATUS: %x\r\n", *(uint8_t *)eventParam);
            break;
            
        case CY_BLE_EVT_GAPP_UPDATE_ADV_SCAN_DATA_COMPLETE:
            DBG_PRINTF("CY_BLE_EVT_GAPP_UPDATE_ADV_SCAN_DATA_COMPLETE\r\n");
            break;
            
        /**********************************************************
        *                       GAP Events
        ***********************************************************/

            
        case CY_BLE_EVT_GAPP_ADVERTISEMENT_START_STOP:
            DBG_PRINTF("CY_BLE_EVT_GAPP_ADVERTISEMENT_START_STOP, state: %x\r\n", Cy_BLE_GetAdvertisementState());
            break;
      
        /**********************************************************
        *                       Other Events
        ***********************************************************/
        case CY_BLE_EVT_PENDING_FLASH_WRITE:
            /* Inform application that flash write is pending. Stack internal data 
            * structures are modified and require to be stored in Flash using 
            * Cy_BLE_StoreBondingData() */
            DBG_PRINTF("CY_BLE_EVT_PENDING_FLASH_WRITE\r\n");
            break;

        default:
            DBG_PRINTF("Other event: 0x%lx \r\n", event);
            break;
    }
}

;   

void StartBroadcast(void)
{
      
    /* Start broadcasting */
Cy_BLE_GAPP_EnterDiscoveryMode(&cy_ble_discoveryModeInfo[0]);
 
}


void StopBroadcast(void)
{
    /* Stop broadcasting (basically stop all forms of advertisement) */
    Cy_BLE_GAPP_ExitDiscoveryMode();
}


 /*
function to dynamically hange the advertising payload, be it a marker or just general content change

*/
void UpdateADVData(void)
{

    advPayload[17] = 0x55;
    advPayload[18]++;
    advPayload[27]--;
    
    DBG_PRINTF("payload 17= %d  18=%d  27=%d \r\n", advPayload[17],advPayload[18],advPayload[27]);
    
    Cy_BLE_GAPP_UpdateAdvScanData(&cy_ble_discoveryModeInfo[0]);
 
}
/* [] END OF FILE */
